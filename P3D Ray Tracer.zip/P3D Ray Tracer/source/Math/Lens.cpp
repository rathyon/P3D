
#include "Lens.h"
//#include <random>
#include "Math.h"

Lens::Lens(const float& radius, const  float& focalDistance, const int& samples, const vec3& pos, const vec3& at, const vec3& up, const float& fovy, const float& near, const float& far, const int& ResX, const int& ResY)
	 :_radius(radius), _focalDistance(focalDistance), _samples(samples) {
	setPos(pos);
	setAt(at);  
	setUp(up);
	setFovy(fovy);
	setNear(near);
	setFar(far);
	setResX(ResX);
	setResY(ResY);
	setLookAt();
	setRight();
	setUp();
	setLensFocalDistance(_focalDistance);
	//setCameraFocalDistance(pos, at);
	setHeight();
	setWidth();
	
	
	
}

Lens::Lens()
{
}

const vec3 Lens::rayDirection(const vec3& pixelPoint, const vec3& lensPoint) {
	//assumindo near como viewPlane
	vec3 point;
	point.x = pixelPoint.x * _focalDistance / getNear();
	point.y = pixelPoint.y * _focalDistance / getNear();

	vec3 dir = (point.x - lensPoint.x) * getRight() + (point.y - lensPoint.y) * getUp() - _focalDistance * getLookAt();
	dir.normalize();

	return dir;
}

const void Lens::generateRandomSamples(const int& samples) {
	
	
	
	for (int i = 0; i < samples;i++) {
	
		float distance = frand() * _radius;
		float angle = frand() * 360.0f;
		float angleToRadians = (angle * PI) / 360.0f;
		float X = cos(angleToRadians);
		float Y = sin(angleToRadians);
		vec3* randomPoint = new vec3(getRight() * distance * X + getUp() * distance * Y + getLookAt());
		randomSamples.push_back(randomPoint);
	}

};

void Lens::clearVector() {
	randomSamples.clear();
}
const float& Lens::getFocalDistance() const {
	return _focalDistance;
}

const float& Lens::getRadius() const {
	return _radius;
}

const int& Lens::getSamples() const {
	return _samples;
}


